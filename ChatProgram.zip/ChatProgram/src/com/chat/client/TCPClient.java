package com.chat.client;

import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) {
        Socket socket = null;

        try {
            socket  = new Socket("localhost", 9876);


            Socket finalSocket = socket;
            Thread sendMessageThread = new Thread(() -> {
                try (PrintWriter writer = new PrintWriter(finalSocket.getOutputStream(), true)) {
                    BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
                    String message;
                    while ((message = consoleReader.readLine()) != null) {
                        writer.println(message);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });


            Socket finalSocket1 = socket;
            Thread receiveMessageThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(finalSocket1.getInputStream()))) {
                    String message;
                    while ((message = reader.readLine()) != null) {
                        System.out.println("Received from server: " + message);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            sendMessageThread.start();
            receiveMessageThread.start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

